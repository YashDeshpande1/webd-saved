var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "TataIndia"
});

con.connect(function(err){
    // var dothis = " SELECT * FROM employee WHERE ssn =100 AND name LIKE CONVERT( _utf8 'michael' USING latin1 ) COLLATE latin1_swedish_ci LIMIT 0 , 30 "
    // con.query(dothis,function(err,result){
    //     if (err) throw err;
    //     console.log(result)
    // })

    var dothis = "  SELECT * FROM `employee` WHERE `gender` LIKE CONVERT( _utf8 'male' USING latin1 ) COLLATE latin1_swedish_ci LIMIT 0 , 30 "
    con.query(dothis,function(err,result){
        if (err) throw err;
        console.log(result)
    })
})