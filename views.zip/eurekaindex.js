const mysql = require('mysql');
const express = require('express');
const session = require('express-session');
const path = require('path');
const alert = require("alert");

const con = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : '',
	database : 'TataIndia'
});

const app = express();

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.get("/",function(req,res){
    res.sendFile("P:/views-atrey/eureka.html");
});

app.post("/newinsert",function(req,res){
    let tempname = req.body.username;
    let temppass = req.body.password;
    let tempssn = req.body.ssn;
    let tempsal = req.body.salary;

    var dothis = "INSERT INTO employee (ssn,name,password,salary) VALUES (?,?,?,?)"

    con.query(dothis,[tempssn,tempname,temppass,tempsal],function(err){
        if (err)
        {
            console.log("<h1>Some error occured while insert</h1>");
            res.redirect("/");
        }
        else{
            console.log("Data Inserted!");
            res.redirect("/");
        }
    });
});

app.post("/newdelete",function(req,res){
    var tempname = req.body.username;

    var dothis = "DELETE FROM `employee` WHERE `employee`.`name` LIKE ?";

    con.query(dothis,[tempname],function(err){
        if(err) throw err;
        console.log(tempname+" Deleted Successfully");
        res.redirect("/");
    });
});

app.post("/newsearch",function(req,res){
    
    var tempssn = req.body.ssn;
    
    var dothis = " SELECT * FROM employee WHERE ssn = ?"
    con.query(dothis,[tempssn],function(err,result){
        if (err) throw err;
        console.log(result);
        alert(result);
        res.redirect("/");
    })
})

app.listen('42069');