const mysql = require('mysql');
const express = require('express');
const session = require('express-session');
const path = require('path');

const connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : '',
	database : 'TataIndia'
});

const app = express();

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'static')));


app.get('/', function(request, response) {
	
	response.sendFile(path.join(__dirname + '/index.html'));
});


app.post('/auth', function(request, response) {
	
	let username = request.body.username;
	let password = request.body.password;
	
	if (username && password) {
		
		connection.query('SELECT * FROM employee WHERE name = ? AND password = ?', [username, password], function(error, results, fields) {
			
			if (error) throw error;
			
			if (results.length > 0) {
				
				request.session.loggedin = true;
				request.session.username = username;
                if(username == 'michael'){
                    response.redirect('/admin');
                }
                else{
                    response.redirect('/user');
                }
			} else {
				response.send('Incorrect Username and/or Password!');
			}			
			response.end();
		});
	} else {
		response.send('Please enter Username and Password!');
		response.end();
	}
});


app.get('/user', function(request, response) {
	
	if (request.session.loggedin) {
		// response.writeHead(200, {'Content-Type': 'text/html'});
		response.send('Welcome back User, ' + request.session.username + '!');
        var des = request.query.designation;
        var dept = request.query.department;
        let sql = `SELECT * FROM employee
                        WHERE designation = 'full-time'
                        AND department = 'production' `;
        let query = connection.query(sql, (err, result) => {
            console.log(result);
        });
	} else {
		
		response.send('Please login to view this page!');
	}
	response.end();
});

app.get('/admin', function(request, response) {
	
	if (request.session.loggedin) {
		
		response.send('Welcome back Admin, ' + request.session.username + '!');
        let sql = "DELETE FROM employee WHERE experience=20 ";
        let query = connection.query(sql, (err, result) => {
            console.log("User with experience of 20 years has been successfully deleted!");
        });
	} else {
		
		response.send('Please login to view this page!');
	}
	response.end();
});

app.listen('3000', () => {
    console.log("Server started on PORT 3000");
})
