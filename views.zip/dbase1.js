var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "TataIndia"
});

con.connect(function(err) {
    console.log("Connected!");
    let sql = "CREATE TABLE employee(ssn INTEGER, name VARCHAR(255),password varchar(12), gender VARCHAR(10), salary int(5), designation varchar(12),department varchar(20), experience int(5), date_of_joining varchar(20), PRIMARY KEY(ssn))";
    con.query(sql, function (err,result){
        if (err) throw err;
        console.log("Table created");
    });
    var data = [
        "INSERT INTO employee (ssn,name,password,gender,salary,designation,department,experience,date_of_joining) VALUES (100,'michael','1234','male',50000,'full-time','Sales',12,'12-10-2022'),(101,'rohan','2345','male',40000,'full-time','Production',15,'12-10-2022'),(102,'Goku','2346','male',35000,'full-time','Production',8,'12-10-2022'),(103,'vegeta','9876','male',45000,'full-time','Sales',20,'12-10-2022'),(104,'bruce','8362','male',60000,'part-time','Production',12,'12-10-2022'),(105,'David','82615','male',56000,'full-time','Sales',2,'12-10-2022')"    
    ];
    for(let i=0;i<data.length;i++){
        con.query(data[i], function (err,result){
            if (err) throw err;
            console.log("Row inserted");
        });
    }
});